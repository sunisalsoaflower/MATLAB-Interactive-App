prompt = 'Choose 1 for Common Source and 2 for Common Emitter : ';
 X = input(prompt);
 
 if (X ==1) 
     amp_CS();
 elseif (X ==2) 
         amp_CE();
     else 
         error = 'TRY AGAIN';
 end
         