
function amp_CE()

I = imread('Fig_CE.png');
figure
imshow(I)


a = 'C1 =  ';
C1 = input(a);
b = 'C2 =  ';
C2 = input(b);
c = 'CE =  ';
Ce = input(c);

d = 'Rsig =  ';
Rsig = input(d);
e = 'Rg =  ';
Rb = input(e);
f = 'Rl =  ';
Rl = input(f);
g = 'Rd =  ';
Rc = input(g);

            gm = 2;
            Re = 1/gm;
            B = 100;
            Rpi = B /gm; 
            Rbpi= (Rb*Rpi)/(Rb+Rpi);
            Rbsig=(Rb*Rsig)/(Rb+Rsig);
            f1= 1/(C1*(Rbpi + Rsig));
            f2= 1/(Ce*(Re + (Rbsig)/(B +1)));   
            f3= 1/(C2*(Rc+ Rl));
            Am= (Rbpi/(Rbpi+Rsig))*gm*((Rc*Rl)/(Rc+Rl));
            H2 = tf([1 0],[1 f2])
            V = Am*H2
            
            figure
           bode(V)
           
end