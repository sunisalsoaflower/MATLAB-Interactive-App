function amp_CS()

I = imread('Fig_CS.png');
figure
imshow(I)


a = 'C1 =  ';
C1 = input(a);
b = 'C2 =  ';
C2 = input(b);
c = 'CS =  ';
CS = input(c);

d = 'Rsig =  ';
Rsig = input(d);
e = 'Rg =  ';
Rg = input(e);
f = 'Rl =  ';
Rl = input(f);
g = 'Rd =  ';
Rd = input(g);

            gm = 2;
            f1= 1/(C1*(Rg + Rsig));
            f2= gm/CS;   
            f3= 1/(C2*(Rd+ Rl));
            Am= (Rg/(Rg+Rsig))*gm*((Rd*Rl)/(Rd+Rl));
            H1 = tf([1 0],[1 f1])
            H2 = tf([1 0],[1 f2])
            H3 = tf([1 0],[1 f3])
            V = Am*H1*H2*H3
                 
            figure
           bode(V)
           
end